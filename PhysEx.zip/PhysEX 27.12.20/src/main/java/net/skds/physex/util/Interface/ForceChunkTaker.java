package net.skds.physex.util.Interface;

public interface ForceChunkTaker {
	
}