package net.skds.physex.util.pars;

public class BlockPhysicsPars {
	
}