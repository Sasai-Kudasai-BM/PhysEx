package net.skds.physex.client;

import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ClientEvents {

	@SubscribeEvent
	public void onBucketEvent(RenderGameOverlayEvent.Post e) {
	}
}