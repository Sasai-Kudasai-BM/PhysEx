package net.skds.physex.util.Interface;

import net.skds.physex.util.pars.CustomBlockPars;

public interface IBlockExtended {
	public CustomBlockPars getCustomBlockPars();
	public void setCustomBlockPars(CustomBlockPars pars);
	
}