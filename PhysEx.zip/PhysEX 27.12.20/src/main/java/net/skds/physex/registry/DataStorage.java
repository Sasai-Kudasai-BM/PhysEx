package net.skds.physex.registry;

public class DataStorage {
	
}