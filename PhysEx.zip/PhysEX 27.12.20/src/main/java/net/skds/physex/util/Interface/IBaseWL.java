package net.skds.physex.util.Interface;

//import net.minecraft.state.IntegerProperty;

public interface IBaseWL {
	//public IntegerProperty getFFL();
}